const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const db = new Database("store.db");
app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(__dirname,"public")));

db.exec(`
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 category TEXT NOT NULL,
 price REAL NOT NULL CHECK(price >= 0),
 stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
 image TEXT NOT NULL,
 description TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_name TEXT NOT NULL,
 customer_email TEXT NOT NULL,
 total REAL NOT NULL CHECK(total >= 0),
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_id INTEGER NOT NULL REFERENCES orders(id),
 product_id INTEGER NOT NULL REFERENCES products(id),
 quantity INTEGER NOT NULL CHECK(quantity > 0),
 unit_price REAL NOT NULL CHECK(unit_price >= 0)
);
`);

const count = db.prepare("SELECT COUNT(*) AS n FROM products").get().n;
if (!count) {
  const add = db.prepare(`INSERT INTO products
    (name,category,price,stock,image,description) VALUES (?,?,?,?,?,?)`);
  const seed = db.transaction(() => {
    [
      ["هاتف ذكي Pro","إلكترونيات",24999,12,"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=700","هاتف حديث بشاشة عالية الجودة وأداء قوي."],
      ["سماعات لاسلكية","إلكترونيات",3499,30,"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700","صوت واضح واتصال لاسلكي سريع."],
      ["ساعة ذكية","إلكترونيات",5999,18,"https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700","متابعة النشاط والتنبيهات اليومية."],
      ["حقيبة ظهر","أزياء",1299,40,"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700","حقيبة عملية للدراسة والعمل."],
      ["كرسي مكتب","منزل",4999,9,"https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=700","تصميم مريح للعمل لفترات طويلة."]
    ].forEach(x=>add.run(...x));
  });
  seed();
}

app.get("/api/products",(req,res)=>{
  const q=String(req.query.q||"").trim().slice(0,80);
  const cat=String(req.query.category||"").trim().slice(0,40);
  let sql="SELECT * FROM products WHERE 1=1", args=[];
  if(q){sql+=" AND (name LIKE ? OR description LIKE ?)"; args.push(`%${q}%`,`%${q}%`);}
  if(cat){sql+=" AND category=?"; args.push(cat);}
  sql+=" ORDER BY id DESC";
  res.json(db.prepare(sql).all(...args));
});

app.get("/api/categories",(req,res)=>{
  res.json(db.prepare("SELECT DISTINCT category FROM products ORDER BY category").all().map(x=>x.category));
});

app.post("/api/orders",(req,res)=>{
  const {customerName,customerEmail,items}=req.body||{};
  if(typeof customerName!=="string" || customerName.trim().length<2 || customerName.length>80)
    return res.status(400).json({error:"اسم العميل غير صالح"});
  if(typeof customerEmail!=="string" || !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(customerEmail) || customerEmail.length>160)
    return res.status(400).json({error:"البريد الإلكتروني غير صالح"});
  if(!Array.isArray(items)||!items.length||items.length>50)
    return res.status(400).json({error:"السلة غير صالحة"});

  const createOrder=db.transaction(()=>{
    let total=0, normalized=[];
    for(const item of items){
      const id=Number(item.productId), qty=Number(item.quantity);
      if(!Number.isInteger(id)||!Number.isInteger(qty)||qty<1||qty>20) throw new Error("بيانات منتج غير صالحة");
      const p=db.prepare("SELECT * FROM products WHERE id=?").get(id);
      if(!p || p.stock<qty) throw new Error(`المخزون غير كافٍ للمنتج: ${p?.name||id}`);
      total += p.price*qty;
      normalized.push({p,qty});
    }
    const order=db.prepare("INSERT INTO orders(customer_name,customer_email,total) VALUES(?,?,?)")
      .run(customerName.trim(),customerEmail.trim().toLowerCase(),total);
    const addItem=db.prepare("INSERT INTO order_items(order_id,product_id,quantity,unit_price) VALUES(?,?,?,?)");
    const dec=db.prepare("UPDATE products SET stock=stock-? WHERE id=?");
    normalized.forEach(({p,qty})=>{addItem.run(order.lastInsertRowid,p.id,qty,p.price);dec.run(qty,p.id);});
    return {id:order.lastInsertRowid,total};
  });
  try { res.status(201).json(createOrder()); }
  catch(e){ res.status(400).json({error:e.message}); }
});

app.get("/api/health",(req,res)=>res.json({ok:true}));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(3000,()=>console.log("Store running on http://localhost:3000"));
