# QA / Security / UX checklist

## Functional
- [ ] البحث يعمل مع نتائج ونتائج صفرية.
- [ ] التصنيفات تعمل.
- [ ] إضافة/زيادة/تقليل/حذف عناصر السلة.
- [ ] إنشاء الطلب.
- [ ] منع الطلب عند نقص المخزون.
- [ ] الخادم يحسب السعر من قاعدة البيانات وليس من العميل.

## Database
- [ ] Foreign keys وconstraints.
- [ ] Transaction لإنشاء الطلب وتحديث المخزون.
- [ ] اختبار concurrent checkout عند التوسع.
- [ ] Backup/restore قبل الإنتاج.

## Security
- [ ] HTTPS في الإنتاج.
- [ ] Secrets خارج source code.
- [ ] Rate limiting.
- [ ] Security headers.
- [ ] CSRF/session strategy عند إضافة الحسابات.
- [ ] Authorization server-side.
- [ ] Dependency scanning وSBOM.
- [ ] Logs بدون بيانات حساسة.
- [ ] اختبار أمني مصرح به فقط.

## UX / Accessibility
- [ ] Keyboard navigation.
- [ ] Labels وfocus واضح.
- [ ] حالات loading/error/empty/success.
- [ ] Responsive على الهاتف.
- [ ] صور لها alt.
- [ ] اختبار RTL.
- [ ] تقليل خطوات checkout.

## Performance
- [ ] ضغط/تحسين الصور.
- [ ] Lazy loading.
- [ ] قياس Core Web Vitals.
- [ ] اختبار شبكة بطيئة وهاتف ضعيف.
- [ ] مراقبة API latency وerror rate.

## AI-generated code review
- [ ] مراجعة بشرية لكل تغيير مهم.
- [ ] فهم كل dependency.
- [ ] عدم قبول مخرجات AI كحقيقة دون اختبار.
- [ ] مراجعة الصلاحيات والمدخلات والبيانات.
