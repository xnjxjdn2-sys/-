const $=s=>document.querySelector(s);
let products=[], cart=JSON.parse(localStorage.getItem("cart")||"{}");
const money=n=>new Intl.NumberFormat("ar-EG",{maximumFractionDigits:2}).format(n);
async function load(url="/api/products"){const r=await fetch(url); products=await r.json(); renderProducts();}
function renderProducts(){
 $("#resultCount").textContent=`${products.length} منتج`;
 $("#grid").innerHTML=products.map(p=>`<article class="card">
<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy">
<div class="card-body"><small>${escapeHtml(p.category)}</small><h3>${escapeHtml(p.name)}</h3>
<p>${escapeHtml(p.description)}</p><div class="price">${money(p.price)} ج.م</div>
<p>المتاح: ${p.stock}</p><button ${p.stock<1?"disabled":""} onclick="add(${p.id})">${p.stock<1?"غير متوفر":"أضف للسلة"}</button></div></article>`).join("");
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function add(id){cart[id]=(cart[id]||0)+1;save();toast("تمت إضافة المنتج للسلة");}
function save(){localStorage.setItem("cart",JSON.stringify(cart));renderCart();}
function renderCart(){
 let total=0,count=0;
 $("#cartItems").innerHTML=Object.entries(cart).map(([id,q])=>{
  const p=products.find(x=>x.id==id); if(!p)return "";
  const qty=Math.min(q,p.stock); cart[id]=qty; total+=p.price*qty;count+=qty;
  return `<div class="cart-row"><div><strong>${escapeHtml(p.name)}</strong><br>${money(p.price)} ج.م</div>
  <div class="qty"><button onclick="change(${p.id},-1)">−</button>${qty}<button onclick="change(${p.id},1)">+</button></div></div>`;
 }).join("");
 $("#cartCount").textContent=count; $("#total").textContent=money(total);
}
function change(id,d){cart[id]=(cart[id]||0)+d;if(cart[id]<=0)delete cart[id];save();}
async function categories(){const r=await fetch("/api/categories"), cs=await r.json();$("#cats").innerHTML=`<button onclick="load()">الكل</button>`+cs.map(c=>`<button onclick="load('/api/products?category=${encodeURIComponent(c)}')">${escapeHtml(c)}</button>`).join("");}
$("#searchForm").addEventListener("submit",e=>{e.preventDefault();load("/api/products?q="+encodeURIComponent($("#q").value));});
$("#cartBtn").onclick=()=>{$("#drawer").classList.add("open");$("#drawer").setAttribute("aria-hidden","false");renderCart()};
$("#closeCart").onclick=()=>{$("#drawer").classList.remove("open");$("#drawer").setAttribute("aria-hidden","true")};
$("#checkout").addEventListener("submit",async e=>{
 e.preventDefault();
 const items=Object.entries(cart).map(([productId,quantity])=>({productId:Number(productId),quantity}));
 if(!items.length){$("#msg").textContent="السلة فارغة";return}
 const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customerName:$("#name").value,customerEmail:$("#email").value,items})});
 const data=await r.json();
 if(!r.ok){$("#msg").textContent=data.error||"تعذر إنشاء الطلب";return}
 $("#msg").textContent=`تم إنشاء الطلب رقم ${data.id} — الإجمالي ${money(data.total)} ج.م`;
 cart={};save();await load();await categories();
});
function toast(t){$("#toast").textContent=t;$("#toast").classList.add("show");setTimeout(()=>$("#toast").classList.remove("show"),1800)}
load();categories();renderCart();